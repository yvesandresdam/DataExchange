class Comarca {

  // TO-DO

  // Implementació de la classe Comarca
  
}
