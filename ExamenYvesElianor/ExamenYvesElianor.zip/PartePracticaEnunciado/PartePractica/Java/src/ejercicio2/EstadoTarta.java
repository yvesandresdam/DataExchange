package ejercicio2;

public enum EstadoTarta {
    BIZCOCHO_SIN_HORNEAR,
    BIZCOCHO_HORNEADO,
    BIZCOCHO_CON_CHOCOLATE,
    BIZCOCHO_CON_GUINDA
}